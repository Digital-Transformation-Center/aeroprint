// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/RadioStatus.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__RADIO_STATUS_H_
#define PX4_MSGS__MSG__RADIO_STATUS_H_

#include "px4_msgs/msg/detail/radio_status__struct.h"
#include "px4_msgs/msg/detail/radio_status__functions.h"
#include "px4_msgs/msg/detail/radio_status__type_support.h"

#endif  // PX4_MSGS__MSG__RADIO_STATUS_H_
