// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ORBIT_STATUS_HPP_
#define PX4_MSGS__MSG__ORBIT_STATUS_HPP_

#include "px4_msgs/msg/detail/orbit_status__struct.hpp"
#include "px4_msgs/msg/detail/orbit_status__builder.hpp"
#include "px4_msgs/msg/detail/orbit_status__traits.hpp"
#include "px4_msgs/msg/detail/orbit_status__type_support.hpp"

#endif  // PX4_MSGS__MSG__ORBIT_STATUS_HPP_
