// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/HoverThrustEstimate.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__HOVER_THRUST_ESTIMATE_H_
#define PX4_MSGS__MSG__HOVER_THRUST_ESTIMATE_H_

#include "px4_msgs/msg/detail/hover_thrust_estimate__struct.h"
#include "px4_msgs/msg/detail/hover_thrust_estimate__functions.h"
#include "px4_msgs/msg/detail/hover_thrust_estimate__type_support.h"

#endif  // PX4_MSGS__MSG__HOVER_THRUST_ESTIMATE_H_
