// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/MagWorkerData.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__MAG_WORKER_DATA_H_
#define PX4_MSGS__MSG__MAG_WORKER_DATA_H_

#include "px4_msgs/msg/detail/mag_worker_data__struct.h"
#include "px4_msgs/msg/detail/mag_worker_data__functions.h"
#include "px4_msgs/msg/detail/mag_worker_data__type_support.h"

#endif  // PX4_MSGS__MSG__MAG_WORKER_DATA_H_
