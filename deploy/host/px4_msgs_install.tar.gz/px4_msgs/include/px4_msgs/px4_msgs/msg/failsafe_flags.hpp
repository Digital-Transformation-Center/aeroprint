// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__FAILSAFE_FLAGS_HPP_
#define PX4_MSGS__MSG__FAILSAFE_FLAGS_HPP_

#include "px4_msgs/msg/detail/failsafe_flags__struct.hpp"
#include "px4_msgs/msg/detail/failsafe_flags__builder.hpp"
#include "px4_msgs/msg/detail/failsafe_flags__traits.hpp"
#include "px4_msgs/msg/detail/failsafe_flags__type_support.hpp"

#endif  // PX4_MSGS__MSG__FAILSAFE_FLAGS_HPP_
