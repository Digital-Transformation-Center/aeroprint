// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/OrbTestLarge.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ORB_TEST_LARGE_H_
#define PX4_MSGS__MSG__ORB_TEST_LARGE_H_

#include "px4_msgs/msg/detail/orb_test_large__struct.h"
#include "px4_msgs/msg/detail/orb_test_large__functions.h"
#include "px4_msgs/msg/detail/orb_test_large__type_support.h"

#endif  // PX4_MSGS__MSG__ORB_TEST_LARGE_H_
