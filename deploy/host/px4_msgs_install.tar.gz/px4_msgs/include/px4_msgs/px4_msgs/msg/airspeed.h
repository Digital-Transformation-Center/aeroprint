// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/Airspeed.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__AIRSPEED_H_
#define PX4_MSGS__MSG__AIRSPEED_H_

#include "px4_msgs/msg/detail/airspeed__struct.h"
#include "px4_msgs/msg/detail/airspeed__functions.h"
#include "px4_msgs/msg/detail/airspeed__type_support.h"

#endif  // PX4_MSGS__MSG__AIRSPEED_H_
