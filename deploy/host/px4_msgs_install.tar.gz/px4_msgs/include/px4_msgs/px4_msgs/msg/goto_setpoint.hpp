// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__GOTO_SETPOINT_HPP_
#define PX4_MSGS__MSG__GOTO_SETPOINT_HPP_

#include "px4_msgs/msg/detail/goto_setpoint__struct.hpp"
#include "px4_msgs/msg/detail/goto_setpoint__builder.hpp"
#include "px4_msgs/msg/detail/goto_setpoint__traits.hpp"
#include "px4_msgs/msg/detail/goto_setpoint__type_support.hpp"

#endif  // PX4_MSGS__MSG__GOTO_SETPOINT_HPP_
