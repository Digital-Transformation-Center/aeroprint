// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__RTL_TIME_ESTIMATE_HPP_
#define PX4_MSGS__MSG__RTL_TIME_ESTIMATE_HPP_

#include "px4_msgs/msg/detail/rtl_time_estimate__struct.hpp"
#include "px4_msgs/msg/detail/rtl_time_estimate__builder.hpp"
#include "px4_msgs/msg/detail/rtl_time_estimate__traits.hpp"
#include "px4_msgs/msg/detail/rtl_time_estimate__type_support.hpp"

#endif  // PX4_MSGS__MSG__RTL_TIME_ESTIMATE_HPP_
