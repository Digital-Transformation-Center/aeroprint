// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/LandingTargetPose.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__LANDING_TARGET_POSE_H_
#define PX4_MSGS__MSG__LANDING_TARGET_POSE_H_

#include "px4_msgs/msg/detail/landing_target_pose__struct.h"
#include "px4_msgs/msg/detail/landing_target_pose__functions.h"
#include "px4_msgs/msg/detail/landing_target_pose__type_support.h"

#endif  // PX4_MSGS__MSG__LANDING_TARGET_POSE_H_
