// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/MavlinkLog.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__MAVLINK_LOG_H_
#define PX4_MSGS__MSG__MAVLINK_LOG_H_

#include "px4_msgs/msg/detail/mavlink_log__struct.h"
#include "px4_msgs/msg/detail/mavlink_log__functions.h"
#include "px4_msgs/msg/detail/mavlink_log__type_support.h"

#endif  // PX4_MSGS__MSG__MAVLINK_LOG_H_
