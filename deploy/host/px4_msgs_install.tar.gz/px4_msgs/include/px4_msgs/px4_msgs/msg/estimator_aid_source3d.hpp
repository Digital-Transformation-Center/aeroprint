// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ESTIMATOR_AID_SOURCE3D_HPP_
#define PX4_MSGS__MSG__ESTIMATOR_AID_SOURCE3D_HPP_

#include "px4_msgs/msg/detail/estimator_aid_source3d__struct.hpp"
#include "px4_msgs/msg/detail/estimator_aid_source3d__builder.hpp"
#include "px4_msgs/msg/detail/estimator_aid_source3d__traits.hpp"
#include "px4_msgs/msg/detail/estimator_aid_source3d__type_support.hpp"

#endif  // PX4_MSGS__MSG__ESTIMATOR_AID_SOURCE3D_HPP_
