// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/GimbalManagerInformation.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__GIMBAL_MANAGER_INFORMATION_H_
#define PX4_MSGS__MSG__GIMBAL_MANAGER_INFORMATION_H_

#include "px4_msgs/msg/detail/gimbal_manager_information__struct.h"
#include "px4_msgs/msg/detail/gimbal_manager_information__functions.h"
#include "px4_msgs/msg/detail/gimbal_manager_information__type_support.h"

#endif  // PX4_MSGS__MSG__GIMBAL_MANAGER_INFORMATION_H_
